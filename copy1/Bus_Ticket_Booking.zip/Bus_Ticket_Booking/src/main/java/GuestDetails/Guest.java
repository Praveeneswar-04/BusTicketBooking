package GuestDetails;

public class Guest {
public static void Guest_User() {
	System.out.println("");
}
}
