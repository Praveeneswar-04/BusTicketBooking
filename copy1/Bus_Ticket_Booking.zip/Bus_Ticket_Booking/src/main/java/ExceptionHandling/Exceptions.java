package ExceptionHandling;

public class Exceptions  {
	 public static void handleException(Exception e) {
	        System.out.println("An error occurred: " + e.getMessage());
	        }
}
