package NotifcationDetails;

public class Email {

}
