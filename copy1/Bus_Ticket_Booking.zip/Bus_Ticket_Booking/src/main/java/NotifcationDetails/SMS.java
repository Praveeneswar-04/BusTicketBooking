package NotifcationDetails;

public class SMS {

}
